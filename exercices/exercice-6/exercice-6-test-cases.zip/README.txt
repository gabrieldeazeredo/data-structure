Arquivo zip gerado em: 28/12/2022 21:17:39 
Este arquivo contém os casos de teste cadastrados até o momento, disponibilizado pelo professor aos alunos.
Exercício: Exercício 06 - Árvore AVL de jogos - PESO *3