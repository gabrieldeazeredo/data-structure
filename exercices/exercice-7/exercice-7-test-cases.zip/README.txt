Arquivo zip gerado em: 28/12/2022 21:16:08 
Este arquivo contém os casos de teste cadastrados até o momento, disponibilizado pelo professor aos alunos.
Exercício: Exercício 07 - Braba Log