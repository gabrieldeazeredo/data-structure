Arquivo zip gerado em: 28/12/2022 20:55:10 
Este arquivo contém os casos de teste cadastrados até o momento, disponibilizado pelo professor aos alunos.
Exercício: Exercício 02 - Pokedex